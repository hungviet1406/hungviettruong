PARALLAX SCROLLING DEMO PART 2
============================
author: mikunpham

blog: http://thachpham.com

============================
This is a demo for parallax scrolling technique with multi background.
Have more fun with web-design!
